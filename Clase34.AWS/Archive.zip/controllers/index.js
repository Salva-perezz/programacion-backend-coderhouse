export { productController } from "./product.controller.js";
